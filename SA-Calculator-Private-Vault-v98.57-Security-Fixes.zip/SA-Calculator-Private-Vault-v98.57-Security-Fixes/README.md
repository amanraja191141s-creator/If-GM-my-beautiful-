# SA Calculator v98.57 — Private Vault Extension

This release preserves the approved v98.55 calculator interface and adds the v98.57 encrypted Private Vault hardening updates, namespace-isolated v2 backups, file-integrity validation, atomic restore, inactivity lock and native FLAG_SECURE support.

## Included
- Full SA Calculator source and Android Capacitor project configuration.
- One authoritative Home stylesheet: `assets/css/rebuild-v98.55.css` (the v98.54 Home layer is removed from the active build chain and source tree).
- Five equal keypad rows sized against the app container width, not stretched to consume leftover screen height.
- Width-scaled key typography, radius and spacing; 48px minimum key dimensions; compact/short/landscape fallbacks.
- Preserved 19 original `data-calc` handlers and four-column/five-row keypad order.
- Android GitHub Actions workflow and generated offline `www/` bundle.

## Release identity
- Package: `1.98.57-v98.57`
- Android versionCode: `1098057`
- Offline cache: `sa-calculator-v98-57-private-vault-v9857`

## Private Vault security updates
- New vault/backup PINs require 8–12 digits; older vaults remain unlockable.
- Import failure cleanup, orphan cleanup, chunk integrity checks and atomic file deletion.
- Namespace-isolated v2 backups with original-vault-PIN authentication and atomic restore.
- Five-minute inactivity lock and PIN field clearing.
- Android FLAG_SECURE protects screenshots, recording and recent-task snapshots.
- Review `MICRO-LEVEL-SECURITY-FIXES-v98.57.md` and `RELEASE-LIMITATIONS-v98.57.md`; native biometric/Keystore, system-wide app lock and isolated private browser remain unimplemented.

## Build and verification
- `npm test`
- `npm run build:web`
- GitHub Actions workflow: `.github/workflows/main.yml`

Physical-device screenshot matching, APK installation and device performance measurements still require a real Android device/build runner.

## Private Vault preview
A HideU-style encrypted local vault is integrated into Tools. See `MICRO-LEVEL-SECURITY-FIXES-v98.57.md` and `RELEASE-LIMITATIONS-v98.57.md` for the verified scope and remaining limitations.

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
const alias = fs.readFileSync(path.join(root, 'SA-Calculator-v98.55-Android-Workflow.yml'), 'utf8');
const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8');

test('v98.57 Android workflow discovers the supplied Private Vault source archive name', () => {
  assert.match(workflow, /SA-Calculator-\(\?:Private-Vault-\)\?v\.\*\\\.zip/);
  assert.match(workflow, /SA-Calculator-Private-Vault-v98\.57-Security-Fixes\.zip/);
  assert.doesNotMatch(workflow, /SA-Calculator-v98\.55-Approved-Neon-Home\.zip/);
});

test('v98.57 Android workflow copies remain byte-identical and diagnostics are current', () => {
  assert.equal(workflow, alias);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.57-v98\.57'/);
  assert.match(workflow, /1098057/);
  assert.match(workflow, /Service-worker cache namespace does not match v98\.57/);
});

test('README release identity and Android versionCode match v98.57', () => {
  assert.match(readme, /SA Calculator v98\.57/);
  assert.match(readme, /1\.98\.57-v98\.57/);
  assert.match(readme, /1098057/);
  assert.doesNotMatch(readme, /versionCode: `1098055`/);
});

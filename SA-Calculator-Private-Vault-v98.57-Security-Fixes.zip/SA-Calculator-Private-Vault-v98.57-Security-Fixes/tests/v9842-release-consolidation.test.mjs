import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const read = p => fs.readFileSync(p, 'utf8');
test('v98.44 loads exactly one production stylesheet while preserving all source layers', () => {
  const html = read('index.html');
  const links = [...html.matchAll(/<link\s+rel="stylesheet"[^>]*href="([^"]+)"/g)].map(m => m[1]);
  assert.deepEqual(links, ['assets/css/app.css']);
  for (const name of ['app-base.css','rebuild-v98.32.css','rebuild-v98.33.css','rebuild-v98.35.css','rebuild-v98.37.css','rebuild-v98.38.css','rebuild-v98.39.css','rebuild-v98.40.css','rebuild-v98.41.css','rebuild-v98.44.css','rebuild-v98.45.css','rebuild-v98.46.css','rebuild-v98.47.css','rebuild-v98.48.css']) assert.ok(fs.existsSync(path.join('assets/css',name)), `missing CSS source ${name}`);
  const bundle = read('assets/css/app.css');
  for (const name of ['app-base.css','rebuild-v98.32.css','rebuild-v98.33.css','rebuild-v98.35.css','rebuild-v98.37.css','rebuild-v98.38.css','rebuild-v98.39.css','rebuild-v98.40.css','rebuild-v98.41.css','rebuild-v98.44.css','rebuild-v98.45.css','rebuild-v98.46.css','rebuild-v98.47.css','rebuild-v98.48.css']) assert.ok(bundle.includes(`Consolidated source: assets/css/${name}`), `bundle missing ${name}`);
});
test('v98.44 build regenerates the one CSS bundle and service worker precaches only that stylesheet', () => {
  const builder = read('scripts/prepare-android-web.mjs');
  const sw = read('service-worker.js');
  assert.match(builder, /writeFile\(path\.join\(root, 'assets\/css\/app\.css'/);
  assert.match(sw, /'\.\/assets\/css\/app\.css'/);
  assert.doesNotMatch(sw, /'\.\/assets\/css\/rebuild-v98\./);
});
test('v98.44 has one active GitHub workflow and one matching downloadable YAML', () => {
  assert.equal(read('.github/workflows/main.yml'), read('SA-Calculator-v98.55-Android-Workflow.yml'));
  assert.deepEqual(fs.readdirSync('.github/workflows').filter(x => x.endsWith('.yml') || x.endsWith('.yaml')), ['main.yml']);
  assert.equal(fs.existsSync('android-apk.yml'), false);
  assert.equal(fs.existsSync('main-v98.32-authoritative-rebuild.yml'), false);
});

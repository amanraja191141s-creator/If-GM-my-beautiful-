# SA Calculator v98.46 — Unified Premium Design System

## Visual changes
- Added one final design-system stylesheet for consistent dark/light palettes, surface colors, borders, radii, controls, tool cards, navigation and responsive sizing.
- Unified card and form-field corner radii and touch-control dimensions without changing calculation handlers or screen IDs.
- Refined Tools search, category chips, two-column cards, icon size, spacing, shadows and focus states.
- Kept the calculator expression/result display borderless.
- Preserved reduced-motion and keyboard-focus accessibility.

## Build changes
- Added `rebuild-v98.46.css` to the canonical CSS source list and required-asset gate.
- Regenerated `assets/css/app.css` and Android `www` bundle.
- Updated package, runtime, PWA manifest, service-worker cache and Android workflow identity to v98.46 / versionCode 1098046.

## Preserved
All existing tool destinations, navigation IDs, calculation engines, currency refresh logic, converter input actions, themes, history and favorites.

# QA Results — SA Calculator v98.46

- Automated regression suite: **312 passed, 0 failed**.
- JavaScript syntax: PASS (`assets/js/app.js`, `scripts/prepare-android-web.mjs`, `scripts/patch-android-native.mjs`).
- Android web bundle: PASS; 22 required assets verified; 12 CSS source layers consolidated into one `app.css` request.
- Source and Android CSS bundle: byte-identical.
- Workflow YAML: parsed successfully.
- Downloadable workflow and active GitHub Actions workflow: byte-identical.
- Package, runtime, HTML, PWA manifest, service-worker cache and workflow version identity: synchronized at `1.98.46-v98.46` / Android versionCode `1098046`.
- ZIP integrity: verified after packaging.

Not yet verified: hosted GitHub Actions APK build, physical Android rendering, touch latency, memory/battery use and long-session performance. These require a real APK build and device test.

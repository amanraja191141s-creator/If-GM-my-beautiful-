# Changelog — v98.57

- Hardened vault setup/unlock concurrency and new PIN policy.
- Added inactivity auto-lock and sensitive input clearing.
- Added orphan chunk cleanup, failed-import cleanup and file-integrity checks.
- Added quota preflight and persistent-storage request where supported.
- Made file deletion atomic across metadata and chunks.
- Isolated main/decoy backup payloads.
- Added two-PIN restore authentication, pre-commit integrity validation and atomic multi-store restore.
- Added native Android FLAG_SECURE protection for screenshots, screen recording and recent-task previews.
- Synchronized package, manifest, UI, offline cache, Android versionCode and workflow to v98.57.
- Added vault hardening regression tests.

Known limitations remain documented in `MICRO-LEVEL-SECURITY-FIXES-v98.57.md`.

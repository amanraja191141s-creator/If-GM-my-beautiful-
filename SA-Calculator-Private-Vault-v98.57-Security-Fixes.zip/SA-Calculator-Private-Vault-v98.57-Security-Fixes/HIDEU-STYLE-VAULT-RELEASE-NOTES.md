# HideU-style Private Vault — release notes

- Added a dedicated Private Vault entry in the navigation drawer.
- Added first-run PIN setup and PIN unlock.
- Added authenticated AES-256-GCM encryption, PBKDF2-HMAC-SHA-256 key derivation, random salts and per-chunk IVs.
- Added encrypted import, file listing, image/video/audio preview, export and deletion.
- Added chunk-level IndexedDB persistence to avoid buffering the entire encrypted source file during import.
- Added offline service-worker precache and Android build-workflow checks for the vault runtime.
- Preserved the original calculator engines, tool destinations, theme and settings systems.
- App hiding/locking, private browser, cloud backup, biometric bridge and intruder capture remain outside this build.

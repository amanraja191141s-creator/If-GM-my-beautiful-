# v98.55 — reference-proportional Home keypad sizing

- Removed the v98.54 Home CSS layer from the active source/build chain and replaced it with one authoritative v98.55 layer.
- Reworked Basic Calculator keypad sizing: five equal rows now derive from app-container width rather than stretching to consume arbitrary leftover height.
- Matched the supplied 852×1846 reference proportions: at 426 CSS px app width, target key row is approximately 87.5 CSS px; at 354 CSS px, approximately 72.7 CSS px.
- Removed the old 14px bottom keypad padding; retained the reference top inset and equal column/row gaps.
- Scaled button radius and numeric/utility/operator typography with the app container width.
- Preserved all 19 original `data-calc` actions, four-column/five-row placement, zero spanning two columns, and 48px minimum button dimensions.
- Added compact-width, short-height, landscape, reduced-motion and older-WebView fallback behavior.
- Updated app version, service-worker cache namespace, offline web bundle and Android workflow to v98.55.

# SA Calculator v98.39 — Screenshot-led Android UI correction

## Fixed
- Removed the touch-focused accessibility skip-link artifact that appeared as a blue outline at the top of the Android screen. Keyboard accessibility remains available on keyboard-capable devices.
- Removed the calculator expression/result display boundary and decorative display frame. Expression and live result remain readable on one open display surface.
- Rebalanced the calculator flex layout and bounded the bottom navigation height/padding to prevent the large unused bottom region seen in the supplied Android screenshot.
- Added Scientific Calculator as a searchable, clearly named entry in the drawer tool menu. It reuses the existing scientific engine and preserves DEG/RAD, trigonometric, logarithmic, power/root, memory and history behavior.
- Cleaned Currency and Unit Converter keypad utility controls to consistent icon actions while retaining accessible action labels and existing input-switch/clear/close behavior.
- Added a new final CSS layer and required it in the Android web bundle and offline service-worker asset list.

## Compatibility
- Existing calculation engine, screen IDs, converter calculations, currency provider behavior, preferences, history, themes and navigation handlers are retained.
- Scientific Calculator is exposed as an additional tool-menu entry, not a duplicate calculation engine or a destructive route migration.

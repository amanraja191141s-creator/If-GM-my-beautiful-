# SA Calculator Private Vault Extension v98.57

## Implemented in this source revision

- Preserved the existing SA Calculator UI, calculation runtime, tool destinations, and existing encrypted file vault.
- Added IndexedDB v3 migration with a dedicated `notes` object store; existing `records` and `chunks` stores are retained.
- Added private notes whose title and body are separately AES-256-GCM encrypted with authenticated context strings before persistence.
- Added a decoy vault PIN derived independently with PBKDF2-SHA-256. Decoy media records and notes use a separate `decoy:` namespace and a separate encryption key. The decoy PIN must differ from the main PIN; replacing an existing decoy is blocked to avoid accidental loss.
- Added an authenticated encrypted backup file format (`SA-VAULT-ENCRYPTED-BACKUP`, version 1) covering the active vault's encrypted records, file chunks, and notes. Backup uses a separately entered 6–12 digit PIN and AES-256-GCM. Restore validates the format and authentication tag before writing data, and can be initiated from the locked screen to recover the encrypted vault database before entering the original vault PIN.
- Added explicit export/restore controls. Users can manually upload the encrypted backup file to their own cloud-drive provider; no automatic cloud account connection or background synchronization is configured.
- Improved lock cleanup to revoke media object URLs and clear private file/note DOM content when the vault locks.
- Kept the external web-link action accurately labelled: it opens the system browser and is not an incognito/private browser.
- Updated release identity to `1.98.57-v98.57`, cache namespace, tests, and Android workflow identity.

## Not implemented / Android platform constraints

These capabilities are deliberately not represented as complete or simulated:

1. Native Android Keystore-backed vault key wrapping and hardware-backed key attestation.
2. Android BiometricPrompt integration bound to a cryptographic operation.
3. Intruder selfie capture. This requires an explicit opt-in, visible runtime camera permission, foreground capture UX, retention controls, and native camera implementation; covert capture is not used.
4. A true private/incognito in-app browser with isolated cookies, cache, downloads, and per-session WebView data directory. The current link action opens the system browser only.
5. Automatic cloud backup/restore. The current backup is an encrypted portable file for manual storage; no provider account, OAuth flow, server, or background sync is configured.
6. Locking arbitrary third-party apps. Android does not expose a general third-party app-lock API to ordinary apps. A user-consented Accessibility-based overlay would be a separate sensitive feature and is not silently enabled.
7. Hiding arbitrary installed apps. `DevicePolicyManager.setApplicationHidden` requires Device Owner/Profile Owner or an authorized delegate. This app does not enroll the device as a device owner and does not claim system-wide app hiding.
8. Managing Android Private Space. Private Space is an OS-managed profile; the app cannot silently move existing installed-app data into it.

## Security and data-loss notes

- Existing file vault remains Web Crypto AES-GCM with PBKDF2-SHA-256 at 310,000 iterations.
- Notes and decoy records are encrypted in the WebView layer. This is not equivalent to a hardware-backed Android Keystore design.
- Backups contain ciphertext records, but backup PIN loss means backup loss. Keep a separate offline copy of the PIN.
- Importing media does not remove originals from Gallery. Verify the encrypted copy before manually deleting originals.
- Clearing app data or uninstalling can destroy local vault data. Verify a backup before any destructive device/app operation.
- No zero-bug, zero-lag, hardware-backed, or physical-device guarantee is claimed from automated tests alone.

## Verification performed in this environment

- `node --check assets/js/private-vault.js`: passed.
- `npm test`: 348 tests passed, 0 failed.
- `npm run build:web`: passed; 31 required assets verified and 18 CSS layers consolidated.
- Generated Android web bundle includes the updated vault runtime and service worker.
- Both Android workflow YAML copies parse successfully.
- APK build, installation, biometric hardware, camera permission UX, cloud-provider OAuth, and physical Android device tests were not run in this environment.

# Release Limitations — v98.57

This is an encrypted web-layer vault running inside a Capacitor WebView. It is not yet a full native vault product.

Not implemented: native biometric authentication, Android Keystore-backed encryption keys, system-wide locking/hiding of other apps, a fully isolated private browser, camera/intruder capture, secure native share provider, rooted-device resistance, and automatic cloud backup. These features must not be advertised as available.

The Android build script now applies FLAG_SECURE to the app window. This prevents ordinary screenshots, screen recordings and recent-task previews, but does not defend against a compromised/rooted OS, external camera capture, or privileged instrumentation.

Backups are now version 2. Export a fresh v2 backup before upgrading from v98.56.1; legacy v1 backups are not accepted by this build.

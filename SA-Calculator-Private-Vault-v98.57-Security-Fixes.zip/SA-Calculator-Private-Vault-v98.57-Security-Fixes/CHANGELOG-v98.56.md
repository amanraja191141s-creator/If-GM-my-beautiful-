# v98.57 — Private Vault extension

- Added encrypted private notes.
- Added separate-key decoy vault namespace and decoy PIN setup.
- Added authenticated encrypted portable backup and restore.
- Added safe lock cleanup for decrypted previews and notes.
- Added accurately labelled system-browser link handoff.
- Updated app release/cache identity and Android build workflow.
- Explicitly documented native Android and provider-dependent capabilities that remain unavailable rather than shipping fake controls.

# SA Calculator v98.57 — Micro-level Private Vault Security Fixes

## Scope and honesty

This release fixes source-level defects in the supplied v98.56.1 web vault and adds native Android screenshot/task-switcher protection to the generated `MainActivity`. It does **not** claim to implement every feature of a commercial vault product. System-wide app locking, a genuinely isolated private browser, biometric authentication, hardware-backed Android Keystore key management, camera/intruder capture, and device-level anti-root protection require additional native design, permissions, plugins and real-device validation. They remain explicitly unsupported.

## Implemented changes

### Authentication and lifecycle
- New vault and decoy PIN creation now require 8–12 digits. Existing 6–7 digit vaults remain unlockable for compatibility; users should create a fresh stronger vault and migrate data to change their PIN because a safe in-place key rotation UI is not present.
- Setup rejects a second vault creation when a configuration already exists.
- Setup/unlock actions are guarded against concurrent taps.
- Failed unlock clears the entered PIN.
- PIN fields are cleared on lock.
- Five-minute inactivity auto-lock is added; backgrounding/page hide also locks.
- The in-memory `CryptoKey` reference is dropped on lock. JavaScript cannot guarantee physical zeroization of engine-managed key memory.

### File integrity and storage
- Import failures clean up chunks written for an uncommitted file.
- Startup removes orphan chunks that have no corresponding file metadata.
- Zero-byte files are retained rather than silently skipped.
- File reconstruction verifies metadata, exact chunk count, sequential indices, and reconstructed plaintext byte length.
- Restore validates chunk IDs, duplicate indices, chunk sequence, chunk counts and plaintext sizes before commit.
- Storage quota is estimated before import when the Storage API is available.
- Persistent storage is requested when supported; browser/OS eviction is still not completely preventable.
- File deletion now removes metadata and chunks in one IndexedDB transaction.
- Corrupt file metadata is shown as an integrity warning instead of being silently hidden.

### Backup and restore
- Backup format v2 includes only the active namespace's config and records. Main and decoy PIN-verifier records are no longer bundled together.
- Restore requires both the backup-encryption PIN and the original vault PIN, then authenticates the namespace configuration and every encrypted payload before writing.
- Restore writes config, file metadata, chunks and notes in one multi-store IndexedDB transaction.
- Restore refuses to replace a different existing vault configuration. A backup from another vault must be restored into an empty app installation to avoid silently orphaning existing data.
- Backup v1 files from previous releases are not accepted by this release; create a new v2 backup from the older app before upgrading.

### Native Android
- The generated `MainActivity` applies `WindowManager.LayoutParams.FLAG_SECURE`, preventing normal screenshots, screen recording and recent-task snapshots for the app window. This applies to the whole app, not only the vault.
- Native feature still not implemented: biometric prompt, Android Keystore integration, app-locking other installed apps, isolated private browser, and secure share/file-provider workflow.

## Security caveats
- PBKDF2-HMAC-SHA-256 uses 310,000 iterations and AES-256-GCM with random 96-bit IVs. This is an application-level design, not an independent cryptographic certification.
- Short numeric PINs remain susceptible to offline guessing if an attacker obtains the IndexedDB database. The stronger 8–12 digit rule applies to new vaults and new backups; native rate limiting and hardware-backed key protection remain outstanding.
- Any same-origin script compromise/XSS can access the unlocked vault session. A Content Security Policy review and dependency/supply-chain review are still required.
- Decrypted exports leave the encrypted vault and can be copied or backed up by Android. The app cannot erase those copies reliably.
- Original media files are not deleted from the gallery by import.
- The “Open web link” action still launches the system browser; it is not private/incognito.

## Validation
- JavaScript syntax checks: passed.
- `npm run build:web`: passed; 31 required assets verified and 18 CSS layers consolidated.
- `npm test`: 362 passed, 0 failed.
- Workflow YAML parsed and release identities synchronized.
- ZIP integrity: checked after packaging.
- Not performed: actual GitHub Actions execution, Android SDK APK build, emulator/device installation, physical-device screenshot verification, performance profiling, penetration test, rooted-device test, biometric/Keystore test.

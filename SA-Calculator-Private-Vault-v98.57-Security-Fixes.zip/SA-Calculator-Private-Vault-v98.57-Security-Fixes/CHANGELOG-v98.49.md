# v98.49 Changelog

- Rebuilt the standalone Scientific Calculator UI to follow the supplied classic scientific calculator reference composition.
- Added a display status strip with DEG/RAD and memory indicators, History and More controls.
- Added working SHIFT alternate mappings for inverse trig, log₂ and eˣ.
- Added DRG angle toggle, caret navigation, sign toggle, delete and clear controls.
- Reorganized scientific functions into a six-column bank and the numeric/operators into a five-column, four-row keypad.
- Kept memory, history, expression, result and angle mode isolated to the Scientific Calculator.
- Kept functions honest: no nonfunctional matrix, integral, derivative, complex-number or graphing buttons are shown.
- Added compact-height and narrow-width layout rules, focus-visible states and light-theme variants.
- Updated release identity, Service Worker cache, Android bundle builder and workflow to v98.49 / versionCode 1098049.


## Follow-up UI correction (v98.49 source polish)
- Removed the redundant in-app top header while preserving Android status/navigation system bars.
- Added Settings as a dedicated fifth bottom-navigation destination.
- Hid primary navigation on individual tool screens and restored it on top-level destinations.
- Reduced basic-keypad visual weight while preserving 48px minimum touch targets.
- Tightened converter selection chrome so only selected currency/unit labels occupy the fields; numeric keypads remain numeric-only.
- Added responsive scientific display sizing and regression coverage.

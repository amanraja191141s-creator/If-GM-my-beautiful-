# v98.57.1 — Workflow and release metadata corrections

- Fixed Android workflow source archive discovery for `SA-Calculator-Private-Vault-v98.57-Security-Fixes.zip`.
- Replaced stale v98.55 workflow error messages with exact v98.57 source guidance.
- Corrected stale cache validation diagnostics.
- Updated README release metadata and Android versionCode to 1098057.
- Added regression tests for workflow archive discovery, synchronized workflow copies and release identity.
- Preserved calculator and vault runtime behavior.

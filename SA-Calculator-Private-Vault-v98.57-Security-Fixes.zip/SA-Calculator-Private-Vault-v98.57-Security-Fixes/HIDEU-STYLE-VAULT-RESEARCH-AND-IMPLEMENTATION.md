# SA Calculator — HideU-style Private Vault implementation

## Research basis
Reviewed Google Play listings for HideU: Calculator Lock, Calculator - Photo Lock, HideYou: Calculator Vault, HideMate and CalculatorVault, plus Android Private Space documentation. Features vary between products and versions; this release does not claim exact replication.

## Implemented in this source package
- Private Vault screen integrated into Tools while preserving calculator screens and existing calculation logic.
- First-run 6–12 digit PIN setup and unlock.
- PBKDF2-HMAC-SHA-256 PIN derivation (310,000 iterations) and AES-256-GCM authenticated encryption.
- Random salt and per-chunk random IV; 1 MiB file chunks; authenticated additional data binds each chunk to its record/index.
- Encrypted metadata (name, MIME type, size); IndexedDB stores ciphertext only.
- Import images, videos, audio and common documents; encrypted local storage; media preview; export and permanent delete.
- Explicit warning that original gallery copies are not automatically deleted.
- Lock-on-pagehide and app-background behavior; no cloud upload/account.

## Not implemented / Android constraints
- Hiding arbitrary installed apps from the system launcher, moving existing app data, or cloning apps. Android Private Space uses a separate profile and installs separate app copies; it is not an API that a regular app can silently control.
- Third-party app lock overlays/accessibility monitoring, intruder selfie, fake/decoy vault, private browser, cloud backup, biometric native bridge, SD-card management and native background media indexing.
- Native filesystem encryption and Android Keystore binding. This implementation uses Web Crypto and IndexedDB inside the app WebView; it is encrypted at application level but has not been penetration-tested.

## Critical user safety
- The PIN is not recoverable. Losing it means the encrypted vault cannot be decrypted.
- Clearing app data or uninstalling the app can permanently erase the local vault.
- Imported copies are encrypted; source originals remain in Gallery/Downloads until the user verifies the copy and manually removes them.
- Large media files require sufficient free storage and WebView memory. Import is chunked to limit peak memory.
- This build is a functional encrypted local-file vault foundation, not a complete HideU-equivalent release.

## QA
Automated source regression tests cover integration and security design markers. Actual Android installation, device-specific WebView behavior, large-file endurance, forensic recovery, accessibility and performance testing remain required before production claims.
